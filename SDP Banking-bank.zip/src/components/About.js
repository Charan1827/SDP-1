import { css, jsx } from "@emotion/react";
import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";

function About() {
    return (
      <div>
        <center>
          <h1> Welcome to SDP Banking</h1>
          
          
          <p>We are the SDP Bankers. We are in this field for almost a long time and providing seamless banking experience over vast 
              period of time.
          </p>
          <p>We are using the robust methodologies of banking and finance system and reinventing them.</p>
          <p>Customers are our first priority and Customer support is one of our criteria points of our bank and we provide the best in
              class customer support and providing 24 By 7 customer support.
          </p>
          <p>
              <li>E Mail: sdp@banking.in</li>
              <li>Contact: 0891 212121212</li>
             
          </p>
              </center>
            <p><b>Address:</b></p>
            <p>Park Street</p>
            <p>First Floor</p>
            <p>Vijayawada</p>
      <h2>Services Offered:</h2>
      <li>Virtual Account</li>
      <li>Online Transactions</li>
      <li>Customer Support</li>
      <li>Transaction History</li>
     
      </div>
    );
  }
  export default About;